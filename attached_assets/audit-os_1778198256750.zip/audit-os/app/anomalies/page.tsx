'use client'
// app/anomalies/page.tsx
import { useState } from 'react'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_ANOMALIES, DEMO_ENGAGEMENTS } from '@/types/audit'
import type { GLAnomaly, RiskLevel } from '@/types/audit'

const RISK_CONFIG = {
  critical: { badge: 'badge-critical', dot: 'bg-red',   label: 'Critical', color: '#ef4444' },
  high:     { badge: 'badge-high',     dot: 'bg-amber', label: 'High',     color: '#f59e0b' },
  medium:   { badge: 'badge-medium',   dot: 'bg-blue',  label: 'Medium',   color: '#3b82f6' },
  low:      { badge: 'badge-low',      dot: 'bg-green', label: 'Low',      color: '#22c55e' },
}

const TYPE_LABELS: Record<string, string> = {
  round_number:   'Round Number',
  weekend_entry:  'Weekend Entry',
  duplicate:      'Duplicate Payment',
  outlier:        'Statistical Outlier',
  large_reversal: 'Large Reversal',
  sequence_gap:   'Sequence Gap',
  unusual_account:'Unusual Account',
}

const STATUS_STYLES: Record<string, string> = {
  unreviewed:   'text-red',
  investigated: 'text-amber',
  cleared:      'text-green',
  finding:      'text-blue',
}

export default function AnomaliesPage() {
  const [anomalies, setAnomalies] = useState<GLAnomaly[]>(DEMO_ANOMALIES)
  const [selected, setSelected] = useState<GLAnomaly | null>(null)
  const [filterRisk, setFilterRisk] = useState<string>('all')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [notes, setNotes] = useState('')
  const [aiLoading, setAiLoading] = useState(false)
  const [aiResponse, setAiResponse] = useState<string | null>(null)
  const [showUpload, setShowUpload] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadDone, setUploadDone] = useState(false)

  const filtered = anomalies.filter(a => {
    const riskOk = filterRisk === 'all' || a.risk_level === filterRisk
    const statusOk = filterStatus === 'all' || a.auditor_status === filterStatus
    return riskOk && statusOk
  })

  const unreviewed = anomalies.filter(a => a.auditor_status === 'unreviewed').length
  const critical = anomalies.filter(a => a.risk_level === 'critical').length

  const updateStatus = (id: string, status: string) => {
    setAnomalies(prev => prev.map(a =>
      a.id === id ? { ...a, auditor_status: status, auditor_notes: notes || a.auditor_notes, reviewed_at: new Date().toISOString() } : a
    ))
    setSelected(prev => prev?.id === id ? { ...prev!, auditor_status: status } : prev)
    setNotes('')
  }

  const handleAIDeepDive = async (anomaly: GLAnomaly) => {
    setAiLoading(true)
    setAiResponse(null)
    try {
      const res = await fetch('/api/analyze-anomaly', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ anomaly }),
      })
      const data = await res.json()
      setAiResponse(data.analysis)
    } catch {
      setAiResponse('AI analysis unavailable. Check your ANTHROPIC_API_KEY in environment variables.')
    } finally {
      setAiLoading(false)
    }
  }

  const handleFakeUpload = () => {
    setUploading(true)
    setTimeout(() => {
      setUploading(false)
      setUploadDone(true)
      setShowUpload(false)
      setTimeout(() => setUploadDone(false), 5000)
    }, 2800)
  }

  return (
    <AppLayout>
      <div className="p-10 max-w-[1200px] animate-fade-up">
        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-[11px] text-dim font-bold tracking-[2px] uppercase mb-2">AI-Powered Detection · TBL FY2025</p>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">GL Anomalies</h1>
            <p className="text-muted text-sm">
              <span className="text-red font-semibold">{unreviewed} unreviewed</span> ·{' '}
              <span className="text-red font-semibold">{critical} critical</span> ·{' '}
              {anomalies.length} total detected
            </p>
          </div>
          <div className="flex gap-3">
            <button className="btn-ghost" onClick={() => setShowUpload(true)}>↑ Upload GL File</button>
            <button className="btn-primary">Export Report</button>
          </div>
        </div>

        {/* Upload success */}
        {uploadDone && (
          <div className="flex items-center gap-3 bg-green/8 border border-green/25 rounded-xl px-5 py-3.5 mb-6 text-green text-sm font-semibold">
            ✓ GL file uploaded and analyzed. 5 anomalies detected across 4,821 journal entries. Review below.
          </div>
        )}

        {/* AI scan status bar */}
        <div className="ai-gradient rounded-xl px-5 py-4 mb-7 flex items-center gap-4">
          <div className="w-8 h-8 bg-blue/20 rounded-lg flex items-center justify-center shrink-0">
            <span className="text-blue text-base">⬡</span>
          </div>
          <div className="flex-1">
            <p className="text-[13px] font-semibold text-white mb-0.5">AI Analysis Complete — TBL FY2025 Trial Balance</p>
            <p className="text-[12px] text-muted">
              Analyzed 4,821 journal entries across 127 accounts · Detected 5 anomalies ·
              Powered by Claude Sonnet · NBAA ISA 240 aligned
            </p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-[11px] text-dim">Analysis run</p>
            <p className="text-[13px] font-semibold text-white">Apr 1, 2026 · 09:14</p>
          </div>
        </div>

        {/* Summary risk strip */}
        <div className="grid grid-cols-4 gap-3 mb-6">
          {(['critical','high','medium','low'] as RiskLevel[]).map(r => {
            const count = anomalies.filter(a => a.risk_level === r).length
            return (
              <button key={r}
                onClick={() => setFilterRisk(filterRisk === r ? 'all' : r)}
                className={`p-4 rounded-xl border transition-all text-left ${
                  filterRisk === r
                    ? `border-[${RISK_CONFIG[r].color}] bg-[${RISK_CONFIG[r].color}]/10`
                    : 'border-border bg-surface hover:border-border-2'
                }`}>
                <div className={`text-2xl font-display font-semibold mb-1 ${
                  r === 'critical' ? 'text-red' : r === 'high' ? 'text-amber' : r === 'medium' ? 'text-blue' : 'text-green'
                }`}>{count}</div>
                <div className="text-[11px] text-dim font-bold uppercase tracking-wider capitalize">{r}</div>
              </button>
            )
          })}
        </div>

        {/* Filters */}
        <div className="flex gap-3 mb-5 items-center">
          <div className="flex gap-1 bg-surface border border-border rounded-xl p-1">
            {[['all','All Status'],['unreviewed','Unreviewed'],['investigated','Investigated'],['cleared','Cleared'],['finding','Finding']].map(([val, label]) => (
              <button key={val} onClick={() => setFilterStatus(val)}
                className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition-all
                  ${filterStatus === val ? 'bg-blue text-white' : 'text-muted hover:text-white'}`}>
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Anomaly table */}
        <div className="card p-0 overflow-hidden mb-5">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-border bg-bg-2/60">
                {['Risk','Type','Account','Amount (TZS)','Date','Journal Ref','Status',''].map(h => (
                  <th key={h} className="px-5 py-3.5 text-left text-[10px] text-dim font-bold tracking-[1.5px] uppercase whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(anomaly => (
                <tr key={anomaly.id}
                  className="border-b border-border last:border-0 hover:bg-surface-2/40 transition-colors cursor-pointer"
                  onClick={() => { setSelected(anomaly); setAiResponse(null) }}>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${RISK_CONFIG[anomaly.risk_level].dot}`} />
                      <span className={RISK_CONFIG[anomaly.risk_level].badge}>{RISK_CONFIG[anomaly.risk_level].label}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-[13px] font-medium text-white whitespace-nowrap">{TYPE_LABELS[anomaly.anomaly_type] ?? anomaly.anomaly_type}</p>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-[13px] text-white">{anomaly.account_name}</p>
                    <p className="text-[11px] text-dim font-mono">{anomaly.account_code}</p>
                  </td>
                  <td className="px-5 py-4">
                    <p className="font-mono text-[13px] font-semibold text-white">
                      {anomaly.amount ? `TZS ${anomaly.amount.toLocaleString()}` : '—'}
                    </p>
                  </td>
                  <td className="px-5 py-4 text-[13px] text-muted whitespace-nowrap">
                    {anomaly.transaction_date ? new Date(anomaly.transaction_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                  </td>
                  <td className="px-5 py-4">
                    <span className="font-mono text-[12px] text-dim">{anomaly.journal_ref ?? '—'}</span>
                  </td>
                  <td className="px-5 py-4">
                    <span className={`text-[12px] font-semibold capitalize ${STATUS_STYLES[anomaly.auditor_status] ?? 'text-muted'}`}>
                      {anomaly.auditor_status === 'unreviewed' ? '● Unreviewed' :
                       anomaly.auditor_status === 'investigated' ? '◌ Investigated' :
                       anomaly.auditor_status === 'cleared' ? '✓ Cleared' : '! Finding'}
                    </span>
                  </td>
                  <td className="px-5 py-4">
                    <button className="text-[12px] text-blue hover:underline" onClick={e => { e.stopPropagation(); setSelected(anomaly); setAiResponse(null) }}>
                      Review →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Detail side panel */}
        {selected && (
          <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
            <div className="w-[560px] bg-surface border-l border-border h-full overflow-y-auto" onClick={e => e.stopPropagation()}>
              {/* Panel header */}
              <div className="px-7 py-5 border-b border-border sticky top-0 bg-surface z-10 flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={RISK_CONFIG[selected.risk_level].badge}>{RISK_CONFIG[selected.risk_level].label} Risk</span>
                    <span className="text-[11px] text-dim font-mono">{selected.journal_ref}</span>
                  </div>
                  <h2 className="font-display text-lg font-semibold text-white">{TYPE_LABELS[selected.anomaly_type]}</h2>
                </div>
                <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl leading-none mt-1">✕</button>
              </div>

              <div className="px-7 py-6 space-y-6">
                {/* Key facts */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Account', value: `${selected.account_name} (${selected.account_code})` },
                    { label: 'Amount', value: selected.amount ? `TZS ${selected.amount.toLocaleString()}` : '—' },
                    { label: 'Transaction Date', value: selected.transaction_date ? new Date(selected.transaction_date).toLocaleDateString('en-GB', { dateStyle: 'long' }) : '—' },
                    { label: 'Journal Reference', value: selected.journal_ref ?? '—' },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-bg-2 rounded-lg p-3 border border-border">
                      <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">{label}</p>
                      <p className="text-[13px] font-semibold text-white font-mono">{value}</p>
                    </div>
                  ))}
                </div>

                {/* Description */}
                <div>
                  <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-2">System Description</p>
                  <p className="text-[13px] text-muted leading-relaxed bg-bg-2 rounded-lg p-4 border border-border">{selected.description}</p>
                </div>

                {/* AI explanation */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-[11px] text-dim font-bold uppercase tracking-wider flex items-center gap-2">
                      <span className="text-blue">⬡</span> AI Analysis
                    </p>
                    <button
                      onClick={() => handleAIDeepDive(selected)}
                      disabled={aiLoading}
                      className="text-[12px] text-blue hover:underline font-medium disabled:opacity-50">
                      {aiLoading ? 'Analyzing...' : aiResponse ? 'Re-analyze' : 'Deep Dive with AI'}
                    </button>
                  </div>

                  {/* Static explanation (always shown) */}
                  <div className="ai-gradient rounded-lg p-4 text-[13px] text-muted leading-relaxed">
                    {selected.ai_explanation}
                  </div>

                  {/* Dynamic AI response */}
                  {aiLoading && (
                    <div className="mt-3 ai-gradient rounded-lg p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 border-2 border-blue/30 border-t-blue rounded-full animate-spin shrink-0" />
                        <p className="text-[13px] text-muted ai-scanning">Claude is analyzing this transaction against ISA 240 and Tanzania tax regulations...</p>
                      </div>
                    </div>
                  )}
                  {aiResponse && !aiLoading && (
                    <div className="mt-3 ai-gradient rounded-lg p-4 text-[13px] text-muted leading-relaxed border-l-2 border-blue">
                      <p className="text-[10px] text-blue font-bold uppercase tracking-wider mb-2">AI Deep Dive Response</p>
                      {aiResponse}
                    </div>
                  )}
                </div>

                {/* Prior auditor notes */}
                {selected.auditor_notes && (
                  <div>
                    <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-2">Auditor Notes</p>
                    <p className="text-[13px] text-muted bg-bg-2 rounded-lg p-4 border border-border leading-relaxed">{selected.auditor_notes}</p>
                    {selected.reviewed_at && (
                      <p className="text-[11px] text-dim mt-2">Reviewed: {new Date(selected.reviewed_at).toLocaleDateString('en-GB', { dateStyle: 'long' })}</p>
                    )}
                  </div>
                )}

                {/* Auditor action */}
                <div>
                  <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-3">Auditor Action</p>
                  <textarea
                    className="input resize-none mb-3"
                    rows={3}
                    placeholder="Add investigation notes, evidence obtained, conclusion..."
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <button className="btn-danger justify-center py-2 text-xs" onClick={() => updateStatus(selected.id, 'finding')}>
                      Raise Finding
                    </button>
                    <button className="btn-amber justify-center py-2 text-xs" onClick={() => updateStatus(selected.id, 'investigated')}>
                      Mark Investigated
                    </button>
                    <button className="btn-ghost justify-center py-2 text-xs border-green/30 text-green hover:bg-green/10" onClick={() => updateStatus(selected.id, 'cleared')}>
                      Clear
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Upload GL modal */}
        {showUpload && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-surface border border-border rounded-2xl p-10 w-[480px]">
              <h2 className="font-display text-xl font-semibold text-white mb-1.5">Upload GL Trial Balance</h2>
              <p className="text-muted text-[13px] mb-7">
                Upload a CSV or Excel export of your client's general ledger. AuditOS will analyze all journal entries for anomalies using AI.
              </p>

              {!uploading ? (
                <>
                  <div className="border-2 border-dashed border-border rounded-xl p-10 text-center mb-5 hover:border-blue/40 transition-colors cursor-pointer" onClick={handleFakeUpload}>
                    <p className="text-3xl mb-3">📊</p>
                    <p className="font-semibold text-white text-[14px] mb-1">Drop your GL file here</p>
                    <p className="text-dim text-[12px]">Supports CSV, XLSX, XLS · Any accounting software format</p>
                  </div>
                  <div className="space-y-2 mb-6">
                    {['TRA EFD reconciliation included','ISA 240 fraud indicators checked','Benford's Law analysis','Duplicate detection across all accounts','Round-number and weekend entry flagging'].map(f => (
                      <div key={f} className="flex items-center gap-2 text-[12px] text-muted">
                        <span className="text-blue text-[10px]">✓</span> {f}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button className="btn-primary flex-1 justify-center py-3" onClick={handleFakeUpload}>Select File & Analyze</button>
                    <button className="btn-ghost py-3 px-6" onClick={() => setShowUpload(false)}>Cancel</button>
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="w-12 h-12 border-2 border-blue/30 border-t-blue rounded-full animate-spin mx-auto mb-4" />
                  <p className="font-semibold text-white mb-1">Analyzing 4,821 journal entries...</p>
                  <p className="text-dim text-[13px]">Running ISA 240 checks, duplicate detection, and Benford's Law analysis</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
