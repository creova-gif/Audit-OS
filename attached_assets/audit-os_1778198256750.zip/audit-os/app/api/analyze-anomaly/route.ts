// app/api/analyze-anomaly/route.ts
import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(req: NextRequest) {
  try {
    const { anomaly } = await req.json()

    const prompt = `You are a senior audit manager at a Big Four firm in Tanzania. You are reviewing a GL anomaly flagged by AI during a statutory audit.

ANOMALY DETAILS:
- Type: ${anomaly.anomaly_type}
- Risk Level: ${anomaly.risk_level}
- Account: ${anomaly.account_name} (${anomaly.account_code})
- Journal Reference: ${anomaly.journal_ref}
- Transaction Date: ${anomaly.transaction_date}
- Amount: TZS ${anomaly.amount?.toLocaleString()}
- Description: ${anomaly.description}

Initial AI explanation: ${anomaly.ai_explanation}

Provide a deeper audit investigation guidance in 3-4 paragraphs covering:
1. Specific audit procedures to perform for this anomaly (what documents to request, who to interview, what to test)
2. Tanzania-specific regulatory considerations (TRA implications, NBAA standards, any TANESCO or sector-specific rules if relevant)
3. Fraud vs error indicators — what would distinguish each scenario
4. Recommended conclusion and working paper documentation approach per ISA 240/315

Be specific, practical, and reference actual ISA standards. Write as a senior audit professional advising a junior auditor. Keep your response under 300 words.`

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 600,
      messages: [{ role: 'user', content: prompt }],
    })

    const analysis = message.content
      .filter(block => block.type === 'text')
      .map(block => (block as { type: 'text'; text: string }).text)
      .join('\n')

    return NextResponse.json({ analysis })
  } catch (error: any) {
    console.error('AI analysis error:', error)
    return NextResponse.json(
      { error: 'AI analysis failed', analysis: 'Unable to connect to AI. Verify ANTHROPIC_API_KEY is set.' },
      { status: 500 }
    )
  }
}
