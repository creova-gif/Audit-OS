// app/api/draft-working-paper/route.ts
import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(req: NextRequest) {
  try {
    const { wp, engagement } = await req.json()

    const sectionGuides: Record<string, string> = {
      planning: 'Include: objective of the working paper, risk assessment considerations, key judgements made, reference to prior year findings if applicable.',
      controls: 'Include: controls identified, testing approach, results of controls testing, conclusion on operating effectiveness, impact on substantive testing scope.',
      substantive: 'Include: objective, population description, sampling methodology, items tested, exceptions identified, conclusion. Reference materiality thresholds.',
      completion: 'Include: summary of work performed, unadjusted misstatements schedule, going concern assessment, subsequent events review, audit opinion rationale.',
    }

    const prompt = `You are a senior audit manager at ${engagement?.client?.name ? `the audit engagement for ${engagement.client.name}` : 'a Big Four firm in Tanzania'}. Draft a professional audit working paper.

WORKING PAPER DETAILS:
- Reference: ${wp.wp_ref}
- Section: ${wp.section}
- Title: ${wp.title}
- Engagement: ${engagement?.engagement_name ?? 'Statutory Audit'}
- Period: ${engagement?.period_start ?? 'FY2025'} to ${engagement?.period_end ?? '31 Dec 2025'}
- Overall Risk: ${engagement?.overall_risk ?? 'medium'}
- Materiality: USD ${engagement?.materiality_usd?.toLocaleString() ?? '850,000'}

SECTION GUIDANCE: ${sectionGuides[wp.section] ?? 'Prepare comprehensive audit documentation per ISA requirements.'}

Draft a professional working paper in markdown format. Include:
- Clear objective statement
- Relevant background/context
- Work performed (numbered procedures)
- Findings/results
- Conclusion

Use proper audit terminology. Reference relevant ISA standards (ISA 315, 330, 240 as applicable). Keep it realistic for a Tanzania statutory audit context. Include NBAA compliance considerations where relevant. Format in clean markdown with ## headers.

Maximum 400 words. Be specific and professional.`

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 800,
      messages: [{ role: 'user', content: prompt }],
    })

    const content = message.content
      .filter(b => b.type === 'text')
      .map(b => (b as { type: 'text'; text: string }).text)
      .join('\n')

    return NextResponse.json({ content })
  } catch (error) {
    console.error('WP draft error:', error)
    return NextResponse.json({ error: 'Draft failed' }, { status: 500 })
  }
}
