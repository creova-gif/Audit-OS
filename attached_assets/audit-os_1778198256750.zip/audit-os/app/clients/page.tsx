'use client'
// app/clients/page.tsx
import { useState } from 'react'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_CLIENTS, DEMO_ENGAGEMENTS } from '@/types/audit'
import type { Client } from '@/types/audit'

const ENTITY_ICONS: Record<string, string> = {
  company: '🏢', parastatal: '🏛', ngo: '🌍', partnership: '🤝',
}
const INDUSTRY_COLORS: Record<string, string> = {
  Manufacturing: 'text-amber', Utilities: 'text-blue', Banking: 'text-green', default: 'text-muted'
}

export default function ClientsPage() {
  const [clients] = useState<Client[]>(DEMO_CLIENTS)
  const [selected, setSelected] = useState<Client | null>(null)
  const [search, setSearch] = useState('')

  const filtered = clients.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.industry?.toLowerCase().includes(search.toLowerCase())
  )

  const getEngagements = (clientId: string) => DEMO_ENGAGEMENTS.filter(e => e.client_id === clientId)

  return (
    <AppLayout>
      <div className="p-10 max-w-[1100px] animate-fade-up">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">Clients</h1>
            <p className="text-muted text-sm">{clients.length} active clients · PwC Tanzania</p>
          </div>
          <button className="btn-primary">+ Add Client</button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-7">
          {[
            { label: 'Total Clients', value: clients.length },
            { label: 'Active Engagements', value: DEMO_ENGAGEMENTS.filter(e => e.status !== 'completed').length },
            { label: 'Industries', value: new Set(clients.map(c => c.industry)).size },
          ].map(s => (
            <div key={s.label} className="stat-card">
              <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">{s.label}</p>
              <p className="font-display text-4xl font-semibold text-white">{s.value}</p>
            </div>
          ))}
        </div>

        <div className="mb-5">
          <input className="input max-w-xs" placeholder="Search clients..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <div className="card p-0 overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-border bg-bg-2/60">
                {['Client','Industry','Type','TIN','FY End','Engagements',''].map(h => (
                  <th key={h} className="px-5 py-3.5 text-left text-[10px] text-dim font-bold tracking-[1.5px] uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(client => {
                const engs = getEngagements(client.id)
                const active = engs.filter(e => e.status !== 'completed').length
                return (
                  <tr key={client.id}
                    className="border-b border-border last:border-0 hover:bg-surface-2/40 transition-colors cursor-pointer"
                    onClick={() => setSelected(client)}>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 bg-bg-2 border border-border rounded-lg flex items-center justify-center text-base shrink-0">
                          {ENTITY_ICONS[client.entity_type ?? 'company'] ?? '🏢'}
                        </div>
                        <div>
                          <p className="font-semibold text-[14px] text-white">{client.name}</p>
                          <p className="text-[11px] text-dim">{client.contact_email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`text-[13px] font-medium ${INDUSTRY_COLORS[client.industry ?? ''] ?? INDUSTRY_COLORS.default}`}>
                        {client.industry ?? '—'}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-[13px] text-muted capitalize">{client.entity_type ?? '—'}</td>
                    <td className="px-5 py-4 font-mono text-[12px] text-dim">{client.tin ?? '—'}</td>
                    <td className="px-5 py-4 text-[13px] text-muted">{client.financial_year_end ?? '—'}</td>
                    <td className="px-5 py-4">
                      <span className={`text-[13px] font-semibold ${active > 0 ? 'text-blue' : 'text-dim'}`}>
                        {active > 0 ? `${active} active` : engs.length > 0 ? `${engs.length} completed` : 'No engagements'}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <button className="text-[12px] text-blue hover:underline">View →</button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* Client detail drawer */}
        {selected && (
          <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
            <div className="w-[460px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="text-2xl mb-2">{ENTITY_ICONS[selected.entity_type ?? 'company']}</div>
                  <h2 className="font-display text-xl font-semibold text-white">{selected.name}</h2>
                  <p className="text-muted text-[13px]">{selected.industry} · {selected.entity_type}</p>
                </div>
                <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl">✕</button>
              </div>
              <div className="space-y-4 mb-6">
                {[
                  ['TIN', selected.tin ?? '—'],
                  ['Financial Year End', selected.financial_year_end ?? '—'],
                  ['Contact', selected.contact_name ?? '—'],
                  ['Email', selected.contact_email ?? '—'],
                  ['Phone', selected.contact_phone ?? '—'],
                ].map(([label, value]) => (
                  <div key={label} className="bg-bg-2 rounded-lg p-3 border border-border">
                    <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">{label}</p>
                    <p className="text-[13px] font-semibold text-white">{value}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="label mb-3">Engagements</p>
                <div className="space-y-2">
                  {getEngagements(selected.id).map(eng => (
                    <div key={eng.id} className="p-3 bg-bg-2 border border-border rounded-lg">
                      <p className="text-[13px] font-medium text-white">{eng.engagement_name}</p>
                      <p className="text-[11px] text-dim capitalize mt-0.5">{eng.status} · {eng.engagement_type.replace('_', ' ')}</p>
                    </div>
                  ))}
                  {getEngagements(selected.id).length === 0 && (
                    <p className="text-[13px] text-dim">No engagements yet</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
