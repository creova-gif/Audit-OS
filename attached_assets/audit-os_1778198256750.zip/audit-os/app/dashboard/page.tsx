'use client'
// app/dashboard/page.tsx
import AppLayout from '@/components/layout/AppLayout'
import Link from 'next/link'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import {
  DEMO_ENGAGEMENTS, DEMO_ANOMALIES, DEMO_FINDINGS,
  DEMO_FIRM, DEMO_STAFF, DEMO_CLIENTS
} from '@/types/audit'

const RISK_CONFIG = {
  critical: { color: '#ef4444', label: 'Critical', badge: 'badge-critical' },
  high:     { color: '#f59e0b', label: 'High',     badge: 'badge-high' },
  medium:   { color: '#3b82f6', label: 'Medium',   badge: 'badge-medium' },
  low:      { color: '#22c55e', label: 'Low',       badge: 'badge-low' },
}

const STATUS_STEPS = ['planning', 'fieldwork', 'review', 'completed']

const anomalyBreakdown = [
  { type: 'Round Numbers', count: 1, color: '#f59e0b' },
  { type: 'Weekend Entries', count: 1, color: '#ef4444' },
  { type: 'Duplicates', count: 1, color: '#f59e0b' },
  { type: 'Outliers', count: 1, color: '#3b82f6' },
  { type: 'Reversals', count: 1, color: '#3b82f6' },
]

export default function DashboardPage() {
  const openFindings = DEMO_FINDINGS.filter(f => f.status === 'open').length
  const unreviewedAnomalies = DEMO_ANOMALIES.filter(a => a.auditor_status === 'unreviewed').length
  const criticalAnomalies = DEMO_ANOMALIES.filter(a => a.risk_level === 'critical').length
  const activeEngagements = DEMO_ENGAGEMENTS.filter(e => e.status !== 'completed' && e.status !== 'archived').length

  return (
    <AppLayout>
      <div className="p-10 max-w-[1200px] animate-fade-up">
        {/* Header */}
        <div className="mb-8">
          <p className="text-[11px] text-dim font-bold tracking-[2px] uppercase mb-2">April 2026 · {DEMO_FIRM.name}</p>
          <h1 className="font-display text-4xl font-semibold text-white mb-2">
            Good morning, {DEMO_STAFF[0].full_name.split(' ')[0]}
          </h1>
          <p className="text-muted text-sm">
            You have{' '}
            <span className="text-red font-semibold">{unreviewedAnomalies} unreviewed GL anomalies</span>
            {' '}and{' '}
            <span className="text-amber font-semibold">{openFindings} open findings</span>
            {' '}requiring attention.
          </p>
        </div>

        {/* Critical alert */}
        {criticalAnomalies > 0 && (
          <div className="flex items-start gap-4 bg-red/8 border border-red/25 rounded-xl px-5 py-4 mb-7">
            <div className="w-8 h-8 bg-red/20 rounded-lg flex items-center justify-center text-red font-bold text-sm shrink-0 mt-0.5">!</div>
            <div className="flex-1">
              <p className="font-semibold text-red text-sm mb-0.5">{criticalAnomalies} Critical Risk Anomaly Detected</p>
              <p className="text-muted text-[13px]">
                A weekend journal entry of TZS 1.84M posted by <span className="font-mono text-amber">system_admin</span> on Dec 28 requires immediate investigation under ISA 240.
              </p>
            </div>
            <Link href="/anomalies" className="btn-danger shrink-0 text-xs py-2">Investigate →</Link>
          </div>
        )}

        {/* Stat cards */}
        <div className="grid grid-cols-4 gap-4 mb-7">
          {[
            { label: 'Active Engagements', value: activeEngagements, accent: '', sub: `${DEMO_ENGAGEMENTS.length} total` },
            { label: 'Unreviewed Anomalies', value: unreviewedAnomalies, accent: 'red', sub: `${criticalAnomalies} critical` },
            { label: 'Open Findings', value: openFindings, accent: 'amber', sub: 'Require management response' },
            { label: 'Working Papers', value: '4', accent: 'green', sub: '1 awaiting sign-off' },
          ].map(s => (
            <div key={s.label} className={`stat-card ${s.accent}`}>
              <p className="text-[10px] text-dim font-bold tracking-[1.5px] uppercase mb-3">{s.label}</p>
              <p className="font-display text-4xl font-semibold text-white leading-none mb-1">{s.value}</p>
              <p className="text-[11px] text-dim">{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Main content grid */}
        <div className="grid grid-cols-[1.4fr_1fr] gap-5 mb-5">
          {/* Active engagements */}
          <div className="card">
            <div className="flex justify-between items-baseline mb-5">
              <p className="font-display text-base font-semibold text-white">Active Engagements</p>
              <Link href="/engagements" className="text-[12px] text-blue hover:underline font-medium">View all →</Link>
            </div>
            <div className="space-y-4">
              {DEMO_ENGAGEMENTS.filter(e => e.status !== 'completed').map(eng => {
                const stepIdx = STATUS_STEPS.indexOf(eng.status)
                const risk = RISK_CONFIG[eng.overall_risk]
                return (
                  <Link key={eng.id} href={`/engagements/${eng.id}`}
                    className="block p-4 bg-bg-2 border border-border rounded-xl hover:border-border-2 transition-all">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="font-semibold text-[14px] text-white leading-snug">{eng.engagement_name}</p>
                        <p className="text-[12px] text-muted mt-0.5">{eng.client?.name}</p>
                      </div>
                      <span className={RISK_CONFIG[eng.overall_risk].badge}>{risk.label} Risk</span>
                    </div>
                    {/* Progress steps */}
                    <div className="flex items-center gap-1">
                      {STATUS_STEPS.map((step, i) => (
                        <div key={step} className="flex-1 flex items-center gap-1">
                          <div className={`h-1.5 flex-1 rounded-full transition-all ${
                            i <= stepIdx ? 'bg-blue' : 'bg-border'
                          }`} />
                          {i < STATUS_STEPS.length - 1 && (
                            <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${i < stepIdx ? 'bg-blue' : 'bg-border'}`} />
                          )}
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between mt-1.5">
                      {STATUS_STEPS.map((step, i) => (
                        <span key={step} className={`text-[10px] font-medium capitalize ${i <= stepIdx ? 'text-blue' : 'text-dim'}`}>
                          {step}
                        </span>
                      ))}
                    </div>
                    <div className="flex justify-between items-center mt-3 pt-3 border-t border-border">
                      <span className="text-[11px] text-dim">
                        Period: {new Date(eng.period_start).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })} — {new Date(eng.period_end).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                      </span>
                      <span className="text-[11px] text-dim">
                        Mat: ${(eng.materiality_usd! / 1000).toFixed(0)}K
                      </span>
                    </div>
                  </Link>
                )
              })}
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-5">
            {/* Anomaly breakdown chart */}
            <div className="card">
              <p className="font-display text-base font-semibold text-white mb-1">Anomalies by Type</p>
              <p className="text-[11px] text-dim mb-5">TBL FY2025 · AI-detected</p>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={anomalyBreakdown} barSize={24} layout="vertical">
                  <XAxis type="number" tick={{ fill: '#3d5068', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="type" tick={{ fill: '#7a8ba8', fontSize: 11 }} axisLine={false} tickLine={false} width={100} />
                  <Tooltip contentStyle={{ background: '#1e2535', border: '1px solid #222c3c', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {anomalyBreakdown.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Recent findings */}
            <div className="card">
              <div className="flex justify-between items-baseline mb-4">
                <p className="font-display text-base font-semibold text-white">Recent Findings</p>
                <Link href="/findings" className="text-[12px] text-blue hover:underline">All →</Link>
              </div>
              <div className="space-y-3">
                {DEMO_FINDINGS.map(f => (
                  <div key={f.id} className="p-3 bg-bg-2 border border-border rounded-lg">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="text-[13px] font-medium text-white leading-snug">{f.title}</p>
                      <span className={`shrink-0 ${RISK_CONFIG[f.risk_level].badge}`}>{f.risk_level}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] text-dim">{f.finding_ref}</span>
                      <span className="text-dim text-[10px]">·</span>
                      <span className={`text-[11px] font-semibold ${f.status === 'open' ? 'text-red' : f.status === 'management_response' ? 'text-amber' : 'text-green'}`}>
                        {f.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Firm-wide stats bar */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: 'Clients', value: DEMO_CLIENTS.length, icon: '🏢' },
            { label: 'Staff Members', value: DEMO_STAFF.length, icon: '👤' },
            { label: 'NBAA Registration', value: DEMO_FIRM.nbaa_reg_no, icon: '✓' },
            { label: 'Subscription', value: 'Firm Plan', icon: '⬡' },
          ].map(s => (
            <div key={s.label} className="card-sm flex items-center gap-3">
              <span className="text-xl">{s.icon}</span>
              <div>
                <p className="text-[10px] text-dim font-bold uppercase tracking-wider">{s.label}</p>
                <p className="text-[14px] font-semibold text-white mt-0.5">{s.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  )
}
