'use client'
// app/data-room/page.tsx
import { useState } from 'react'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_DATA_ROOM } from '@/types/audit'
import type { DataRoomItem } from '@/types/audit'

const CATEGORIES = ['financial_statements','bank_statements','tax_returns','contracts','board_minutes','other']
const CATEGORY_ICONS: Record<string, string> = {
  financial_statements: '📊', bank_statements: '🏦', tax_returns: '🧾',
  contracts: '📋', board_minutes: '📝', other: '📁',
}
const STATUS_CONFIG: Record<string, { badge: string; label: string }> = {
  requested: { badge: 'badge-pending',  label: '◌ Requested' },
  received:  { badge: 'badge-medium',   label: '● Received' },
  reviewed:  { badge: 'badge-active',   label: '✓ Reviewed' },
  queried:   { badge: 'badge-critical', label: '! Queried' },
}

export default function DataRoomPage() {
  const [items, setItems] = useState<DataRoomItem[]>(DEMO_DATA_ROOM)
  const [selected, setSelected] = useState<DataRoomItem | null>(null)
  const [filterCat, setFilterCat] = useState<string>('all')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ category: 'financial_statements', item_name: '', description: '', due_date: '' })
  const [uploading, setUploading] = useState<string | null>(null)

  const filtered = items.filter(i => {
    const catOk = filterCat === 'all' || i.category === filterCat
    const statusOk = filterStatus === 'all' || i.status === filterStatus
    return catOk && statusOk
  })

  const received = items.filter(i => i.status === 'received' || i.status === 'reviewed').length
  const outstanding = items.filter(i => i.status === 'requested').length
  const queried = items.filter(i => i.status === 'queried').length

  const handleFakeUpload = (id: string) => {
    setUploading(id)
    setTimeout(() => {
      setItems(prev => prev.map(i => i.id === id ? {
        ...i,
        status: 'received',
        received_at: new Date().toISOString(),
        file_name: `Document_${Date.now()}.pdf`,
        file_url: '#',
      } : i))
      setSelected(prev => prev?.id === id ? { ...prev, status: 'received', received_at: new Date().toISOString(), file_name: `Document_${Date.now()}.pdf` } : prev)
      setUploading(null)
    }, 1800)
  }

  const handleCreate = () => {
    if (!form.item_name) return
    const newItem: DataRoomItem = {
      id: `dr-${Date.now()}`,
      engagement_id: 'eng-001',
      category: form.category,
      item_name: form.item_name,
      description: form.description || null,
      requested_at: new Date().toISOString(),
      due_date: form.due_date || null,
      received_at: null,
      file_url: null,
      file_name: null,
      status: 'requested',
      requested_by: 'staff-002',
      created_at: new Date().toISOString(),
    }
    setItems(prev => [...prev, newItem])
    setForm({ category: 'financial_statements', item_name: '', description: '', due_date: '' })
    setShowNew(false)
  }

  return (
    <AppLayout>
      <div className="p-10 max-w-[1100px] animate-fade-up">
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-[11px] text-dim font-bold tracking-[2px] uppercase mb-2">TBL FY2025 · Secure Client Portal</p>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">Data Room</h1>
            <p className="text-muted text-sm">{items.length} items · {received} received · {outstanding} outstanding</p>
          </div>
          <div className="flex gap-3">
            <button className="btn-ghost">Send Client Reminder</button>
            <button className="btn-primary" onClick={() => setShowNew(true)}>+ Request Item</button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-7">
          <div className="stat-card green">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Received</p>
            <p className="font-display text-4xl font-semibold text-green leading-none mb-1">{received}</p>
            <p className="text-[11px] text-dim">Documents in hand</p>
          </div>
          <div className="stat-card amber">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Outstanding</p>
            <p className="font-display text-4xl font-semibold text-amber leading-none mb-1">{outstanding}</p>
            <p className="text-[11px] text-dim">Awaiting from client</p>
          </div>
          <div className="stat-card red">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Queried</p>
            <p className="font-display text-4xl font-semibold text-red leading-none mb-1">{queried}</p>
            <p className="text-[11px] text-dim">Clarification required</p>
          </div>
        </div>

        {/* Category filter chips */}
        <div className="flex gap-2 mb-4 flex-wrap">
          <button onClick={() => setFilterCat('all')}
            className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold border transition-all
              ${filterCat === 'all' ? 'bg-blue border-blue text-white' : 'border-border text-muted hover:border-border-2'}`}>
            All Categories
          </button>
          {CATEGORIES.map(c => (
            <button key={c} onClick={() => setFilterCat(c)}
              className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold border transition-all flex items-center gap-1.5 capitalize
                ${filterCat === c ? 'bg-blue border-blue text-white' : 'border-border text-muted hover:border-border-2'}`}>
              <span>{CATEGORY_ICONS[c]}</span> {c.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex gap-1 bg-surface border border-border rounded-xl p-1 mb-5 w-fit">
          {[['all','All'],['requested','Requested'],['received','Received'],['reviewed','Reviewed'],['queried','Queried']].map(([val, label]) => (
            <button key={val} onClick={() => setFilterStatus(val)}
              className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition-all
                ${filterStatus === val ? 'bg-blue text-white' : 'text-muted hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* Items list */}
        <div className="space-y-3">
          {filtered.map(item => (
            <div key={item.id} className="card-hover flex items-center gap-4" onClick={() => setSelected(item)}>
              <div className="w-10 h-10 bg-bg-2 border border-border rounded-xl flex items-center justify-center text-xl shrink-0">
                {CATEGORY_ICONS[item.category] ?? '📁'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-0.5">
                  <p className="font-semibold text-[14px] text-white">{item.item_name}</p>
                  <span className={STATUS_CONFIG[item.status]?.badge ?? 'badge-neutral'}>{STATUS_CONFIG[item.status]?.label ?? item.status}</span>
                </div>
                <p className="text-[12px] text-muted line-clamp-1">{item.description ?? item.category.replace('_', ' ')}</p>
                {item.file_name && <p className="text-[11px] text-green font-mono mt-0.5">📎 {item.file_name}</p>}
              </div>
              <div className="text-right shrink-0">
                {item.due_date && (
                  <p className="text-[11px] text-dim">Due {new Date(item.due_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</p>
                )}
                {item.received_at && (
                  <p className="text-[11px] text-green">Received {new Date(item.received_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</p>
                )}
                {uploading === item.id && (
                  <div className="flex items-center gap-1.5 text-[11px] text-blue">
                    <div className="w-3 h-3 border border-blue/30 border-t-blue rounded-full animate-spin" />
                    Uploading...
                  </div>
                )}
              </div>
              {item.status === 'requested' && uploading !== item.id && (
                <button className="btn-primary text-xs py-2 shrink-0"
                  onClick={e => { e.stopPropagation(); handleFakeUpload(item.id) }}>
                  Upload File
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Detail drawer */}
        {selected && (
          <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
            <div className="w-[460px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className={STATUS_CONFIG[selected.status]?.badge ?? 'badge-neutral'}>{STATUS_CONFIG[selected.status]?.label}</span>
                  <h2 className="font-display text-lg font-semibold text-white mt-2">{selected.item_name}</h2>
                  <p className="text-muted text-[13px] capitalize">{selected.category.replace('_', ' ')}</p>
                </div>
                <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl">✕</button>
              </div>
              <div className="space-y-4">
                {selected.description && (
                  <div>
                    <p className="label">Description</p>
                    <p className="text-[13px] text-muted bg-bg-2 rounded-lg p-3 border border-border">{selected.description}</p>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-bg-2 rounded-lg p-3 border border-border">
                    <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Requested</p>
                    <p className="text-[13px] text-white">{new Date(selected.requested_at).toLocaleDateString('en-GB', { dateStyle: 'medium' })}</p>
                  </div>
                  <div className="bg-bg-2 rounded-lg p-3 border border-border">
                    <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Due Date</p>
                    <p className="text-[13px] text-white">{selected.due_date ? new Date(selected.due_date).toLocaleDateString('en-GB', { dateStyle: 'medium' }) : '—'}</p>
                  </div>
                  {selected.received_at && (
                    <div className="bg-bg-2 rounded-lg p-3 border border-border col-span-2">
                      <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Received</p>
                      <p className="text-[13px] text-green">{new Date(selected.received_at).toLocaleDateString('en-GB', { dateStyle: 'medium' })}</p>
                    </div>
                  )}
                </div>
                {selected.file_name && (
                  <div className="bg-green/6 border border-green/20 rounded-lg p-4 flex items-center gap-3">
                    <span className="text-2xl">📎</span>
                    <div>
                      <p className="text-[13px] font-semibold text-white">{selected.file_name}</p>
                      <p className="text-[11px] text-green">Securely stored · Encrypted</p>
                    </div>
                    <button className="btn-ghost text-xs py-1.5 px-3 ml-auto">Download</button>
                  </div>
                )}
                {selected.status === 'requested' && (
                  <button className="btn-primary w-full justify-center py-3" onClick={() => handleFakeUpload(selected.id)}>
                    Upload File
                  </button>
                )}
                {selected.status === 'received' && (
                  <button className="btn-ghost w-full justify-center py-3 border-green/30 text-green hover:bg-green/10"
                    onClick={() => { setItems(prev => prev.map(i => i.id === selected.id ? { ...i, status: 'reviewed' } : i)); setSelected(prev => prev ? { ...prev, status: 'reviewed' } : prev) }}>
                    Mark as Reviewed ✓
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* New request modal */}
        {showNew && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-surface border border-border rounded-2xl p-8 w-[440px]">
              <h2 className="font-display text-xl font-semibold text-white mb-6">Request Document</h2>
              <div className="space-y-4">
                <div>
                  <label className="label">Category</label>
                  <select className="input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                    {CATEGORIES.map(c => <option key={c} value={c} className="capitalize">{c.replace('_', ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Document Name *</label>
                  <input className="input" placeholder="e.g. Fixed Asset Register FY2025" value={form.item_name} onChange={e => setForm(f => ({ ...f, item_name: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Description</label>
                  <textarea className="input resize-none" rows={2} placeholder="Describe what's needed..." value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Due Date</label>
                  <input className="input" type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreate}>Send Request</button>
                <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
