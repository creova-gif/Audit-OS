'use client'
// app/engagements/page.tsx
import { useState } from 'react'
import Link from 'next/link'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_ENGAGEMENTS, DEMO_CLIENTS } from '@/types/audit'
import type { Engagement, EngagementStatus, RiskLevel } from '@/types/audit'

const STATUS_STEPS = ['planning','fieldwork','review','completed']
const RISK_CONFIG = {
  critical: { badge: 'badge-critical', label: 'Critical' },
  high:     { badge: 'badge-high',     label: 'High' },
  medium:   { badge: 'badge-medium',   label: 'Medium' },
  low:      { badge: 'badge-low',      label: 'Low' },
}
const ENG_TYPES = ['statutory_audit','internal_audit','tax_review','forensic','due_diligence']

export default function EngagementsPage() {
  const [engagements, setEngagements] = useState<Engagement[]>(DEMO_ENGAGEMENTS)
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({
    engagement_name: '', client_id: DEMO_CLIENTS[0].id, engagement_type: 'statutory_audit',
    period_start: '', period_end: '', overall_risk: 'medium' as RiskLevel,
    materiality_usd: '', notes: '',
  })

  const active = engagements.filter(e => e.status !== 'completed' && e.status !== 'archived').length

  const handleCreate = () => {
    if (!form.engagement_name || !form.period_start) return
    const client = DEMO_CLIENTS.find(c => c.id === form.client_id)
    const newEng: Engagement = {
      id: `eng-${Date.now()}`,
      firm_id: 'firm-001',
      client_id: form.client_id,
      engagement_name: form.engagement_name,
      period_start: form.period_start,
      period_end: form.period_end,
      engagement_type: form.engagement_type,
      status: 'planning',
      partner_id: 'staff-001',
      manager_id: 'staff-002',
      materiality_usd: form.materiality_usd ? parseFloat(form.materiality_usd) : null,
      performance_mat_usd: form.materiality_usd ? parseFloat(form.materiality_usd) * 0.75 : null,
      overall_risk: form.overall_risk,
      report_date: null,
      signed_off_at: null,
      notes: form.notes || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      client,
    }
    setEngagements(prev => [newEng, ...prev])
    setShowNew(false)
    setForm({ engagement_name: '', client_id: DEMO_CLIENTS[0].id, engagement_type: 'statutory_audit', period_start: '', period_end: '', overall_risk: 'medium', materiality_usd: '', notes: '' })
  }

  return (
    <AppLayout>
      <div className="p-10 max-w-[1100px] animate-fade-up">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">Engagements</h1>
            <p className="text-muted text-sm">{engagements.length} engagements · {active} active</p>
          </div>
          <button className="btn-primary" onClick={() => setShowNew(true)}>+ New Engagement</button>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-7">
          {[
            { label: 'Active', value: active, accent: '' },
            { label: 'In Review', value: engagements.filter(e => e.status === 'review').length, accent: 'amber' },
            { label: 'Completed', value: engagements.filter(e => e.status === 'completed').length, accent: 'green' },
          ].map(s => (
            <div key={s.label} className={`stat-card ${s.accent}`}>
              <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">{s.label}</p>
              <p className="font-display text-4xl font-semibold text-white">{s.value}</p>
            </div>
          ))}
        </div>

        <div className="space-y-4">
          {engagements.map(eng => {
            const stepIdx = STATUS_STEPS.indexOf(eng.status)
            return (
              <div key={eng.id} className="card-hover">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className={RISK_CONFIG[eng.overall_risk].badge}>{RISK_CONFIG[eng.overall_risk].label} Risk</span>
                      <span className="text-[11px] text-dim capitalize">{eng.engagement_type.replace(/_/g,' ')}</span>
                    </div>
                    <h3 className="font-display font-semibold text-[16px] text-white">{eng.engagement_name}</h3>
                    <p className="text-[13px] text-muted">{eng.client?.name}</p>
                  </div>
                  <div className="text-right shrink-0">
                    {eng.materiality_usd && (
                      <p className="text-[13px] font-semibold text-white">Mat: ${(eng.materiality_usd/1000).toFixed(0)}K</p>
                    )}
                    <p className="text-[11px] text-dim mt-0.5">
                      {new Date(eng.period_start).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })} – {new Date(eng.period_end).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 mb-1">
                  {STATUS_STEPS.map((step, i) => (
                    <div key={step} className="flex-1 flex items-center gap-0.5">
                      <div className={`h-1.5 flex-1 rounded-full ${i <= stepIdx ? 'bg-blue' : 'bg-border'}`} />
                      {i < STATUS_STEPS.length - 1 && <div className={`w-1 h-1 rounded-full shrink-0 ${i < stepIdx ? 'bg-blue' : 'bg-border'}`} />}
                    </div>
                  ))}
                </div>
                <div className="flex justify-between">
                  {STATUS_STEPS.map((step, i) => (
                    <span key={step} className={`text-[10px] font-semibold capitalize ${i === stepIdx ? 'text-blue' : i < stepIdx ? 'text-blue/50' : 'text-dim'}`}>
                      {step}
                    </span>
                  ))}
                </div>
                {eng.notes && <p className="text-[12px] text-dim mt-3 pt-3 border-t border-border line-clamp-1">{eng.notes}</p>}
              </div>
            )
          })}
        </div>

        {showNew && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-surface border border-border rounded-2xl p-8 w-[520px] max-h-[90vh] overflow-y-auto">
              <h2 className="font-display text-xl font-semibold text-white mb-6">New Engagement</h2>
              <div className="space-y-4">
                <div>
                  <label className="label">Engagement Name *</label>
                  <input className="input" placeholder="e.g. CRDB Bank Statutory Audit FY2026" value={form.engagement_name} onChange={e => setForm(f => ({ ...f, engagement_name: e.target.value }))} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Client</label>
                    <select className="input" value={form.client_id} onChange={e => setForm(f => ({ ...f, client_id: e.target.value }))}>
                      {DEMO_CLIENTS.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Engagement Type</label>
                    <select className="input" value={form.engagement_type} onChange={e => setForm(f => ({ ...f, engagement_type: e.target.value }))}>
                      {ENG_TYPES.map(t => <option key={t} value={t} className="capitalize">{t.replace(/_/g,' ')}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Period Start *</label>
                    <input className="input" type="date" value={form.period_start} onChange={e => setForm(f => ({ ...f, period_start: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Period End</label>
                    <input className="input" type="date" value={form.period_end} onChange={e => setForm(f => ({ ...f, period_end: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Overall Risk</label>
                    <select className="input" value={form.overall_risk} onChange={e => setForm(f => ({ ...f, overall_risk: e.target.value as RiskLevel }))}>
                      {(['critical','high','medium','low'] as RiskLevel[]).map(r => <option key={r} value={r} className="capitalize">{r.charAt(0).toUpperCase() + r.slice(1)}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Materiality (USD)</label>
                    <input className="input" type="number" placeholder="850000" value={form.materiality_usd} onChange={e => setForm(f => ({ ...f, materiality_usd: e.target.value }))} />
                  </div>
                </div>
                <div>
                  <label className="label">Notes</label>
                  <textarea className="input resize-none" rows={2} placeholder="Key risks, special considerations..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreate}>Create Engagement</button>
                <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
