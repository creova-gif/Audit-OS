'use client'
// app/findings/page.tsx
import { useState } from 'react'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_FINDINGS, DEMO_ANOMALIES } from '@/types/audit'
import type { Finding, FindingStatus, RiskLevel } from '@/types/audit'

const RISK_CONFIG = {
  critical: { badge: 'badge-critical', label: 'Critical' },
  high:     { badge: 'badge-high',     label: 'High' },
  medium:   { badge: 'badge-medium',   label: 'Medium' },
  low:      { badge: 'badge-low',      label: 'Low' },
}
const STATUS_CONFIG: Record<FindingStatus, { badge: string; label: string; color: string }> = {
  open:                { badge: 'badge-critical', label: '● Open',                color: 'text-red' },
  management_response: { badge: 'badge-pending',  label: '◌ Management Response', color: 'text-amber' },
  resolved:            { badge: 'badge-active',   label: '✓ Resolved',            color: 'text-green' },
  escalated:           { badge: 'badge-critical', label: '! Escalated',           color: 'text-red' },
}

export default function FindingsPage() {
  const [findings, setFindings] = useState<Finding[]>(DEMO_FINDINGS)
  const [selected, setSelected] = useState<Finding | null>(null)
  const [response, setResponse] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({
    finding_ref: '', title: '', description: '',
    risk_level: 'medium' as RiskLevel,
    isa_reference: '', due_date: '',
  })

  const handleAddResponse = (id: string) => {
    setFindings(prev => prev.map(f => f.id === id ? { ...f, management_response: response, status: 'management_response' as FindingStatus } : f))
    setSelected(prev => prev?.id === id ? { ...prev, management_response: response, status: 'management_response' as FindingStatus } : prev)
    setResponse('')
  }

  const handleResolve = (id: string) => {
    setFindings(prev => prev.map(f => f.id === id ? { ...f, status: 'resolved' as FindingStatus, resolved_at: new Date().toISOString() } : f))
    setSelected(prev => prev?.id === id ? { ...prev, status: 'resolved' as FindingStatus } : prev)
  }

  const handleCreate = () => {
    if (!form.finding_ref || !form.title) return
    const newFinding: Finding = {
      id: `find-${Date.now()}`,
      engagement_id: 'eng-001',
      anomaly_id: null,
      finding_ref: form.finding_ref,
      title: form.title,
      description: form.description,
      risk_level: form.risk_level,
      isa_reference: form.isa_reference || null,
      nbaa_reference: null,
      management_response: null,
      status: 'open',
      due_date: form.due_date || null,
      resolved_at: null,
      raised_by: 'staff-002',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setFindings(prev => [newFinding, ...prev])
    setForm({ finding_ref: '', title: '', description: '', risk_level: 'medium', isa_reference: '', due_date: '' })
    setShowNew(false)
  }

  const open = findings.filter(f => f.status === 'open').length
  const withResponse = findings.filter(f => f.status === 'management_response').length
  const resolved = findings.filter(f => f.status === 'resolved').length

  return (
    <AppLayout>
      <div className="p-10 max-w-[1100px] animate-fade-up">
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-[11px] text-dim font-bold tracking-[2px] uppercase mb-2">TBL FY2025 Statutory Audit</p>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">Audit Findings</h1>
            <p className="text-muted text-sm">{findings.length} findings · {open} open · {withResponse} awaiting resolution</p>
          </div>
          <button className="btn-primary" onClick={() => setShowNew(true)}>+ Raise Finding</button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-7">
          <div className="stat-card red">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Open</p>
            <p className="font-display text-4xl font-semibold text-red leading-none mb-1">{open}</p>
            <p className="text-[11px] text-dim">Awaiting management response</p>
          </div>
          <div className="stat-card amber">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Management Response</p>
            <p className="font-display text-4xl font-semibold text-amber leading-none mb-1">{withResponse}</p>
            <p className="text-[11px] text-dim">Response received, monitoring</p>
          </div>
          <div className="stat-card green">
            <p className="text-[10px] text-dim font-bold tracking-wider uppercase mb-3">Resolved</p>
            <p className="font-display text-4xl font-semibold text-green leading-none mb-1">{resolved}</p>
            <p className="text-[11px] text-dim">Satisfactorily addressed</p>
          </div>
        </div>

        {/* Findings list */}
        <div className="space-y-3 mb-5">
          {findings.map(finding => (
            <div key={finding.id} className="card-hover" onClick={() => { setSelected(finding); setResponse('') }}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1.5">
                    <span className="font-mono text-[12px] text-blue bg-blue/10 border border-blue/20 rounded px-2 py-0.5">{finding.finding_ref}</span>
                    <span className={RISK_CONFIG[finding.risk_level].badge}>{RISK_CONFIG[finding.risk_level].label}</span>
                    <span className={STATUS_CONFIG[finding.status].badge}>{STATUS_CONFIG[finding.status].label}</span>
                  </div>
                  <h3 className="font-semibold text-[15px] text-white mb-1">{finding.title}</h3>
                  <p className="text-[13px] text-muted line-clamp-2">{finding.description}</p>
                </div>
                <div className="text-right shrink-0">
                  {finding.isa_reference && (
                    <p className="font-mono text-[11px] text-dim bg-surface-2 border border-border rounded px-2 py-0.5 mb-2">{finding.isa_reference}</p>
                  )}
                  {finding.due_date && (
                    <p className="text-[11px] text-dim">Due: {new Date(finding.due_date).toLocaleDateString('en-GB', { dateStyle: 'medium' })}</p>
                  )}
                </div>
              </div>
              {finding.management_response && (
                <div className="mt-3 pt-3 border-t border-border">
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Management Response</p>
                  <p className="text-[12px] text-muted line-clamp-2">{finding.management_response}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Detail drawer */}
        {selected && (
          <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
            <div className="w-[520px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-mono text-[12px] text-blue bg-blue/10 border border-blue/20 rounded px-2 py-0.5">{selected.finding_ref}</span>
                    <span className={RISK_CONFIG[selected.risk_level].badge}>{RISK_CONFIG[selected.risk_level].label}</span>
                    <span className={STATUS_CONFIG[selected.status].badge}>{STATUS_CONFIG[selected.status].label}</span>
                  </div>
                  <h2 className="font-display text-lg font-semibold text-white">{selected.title}</h2>
                </div>
                <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl">✕</button>
              </div>

              <div className="space-y-5">
                <div>
                  <p className="label">Description</p>
                  <p className="text-[13px] text-muted leading-relaxed bg-bg-2 rounded-lg p-4 border border-border">{selected.description}</p>
                </div>

                {selected.isa_reference && (
                  <div>
                    <p className="label">ISA Reference</p>
                    <p className="font-mono text-[13px] text-blue">{selected.isa_reference}</p>
                  </div>
                )}

                {selected.due_date && (
                  <div>
                    <p className="label">Due Date</p>
                    <p className="text-[13px] text-white">{new Date(selected.due_date).toLocaleDateString('en-GB', { dateStyle: 'long' })}</p>
                  </div>
                )}

                {selected.management_response && (
                  <div>
                    <p className="label">Management Response</p>
                    <p className="text-[13px] text-muted leading-relaxed bg-bg-2 rounded-lg p-4 border border-border">{selected.management_response}</p>
                  </div>
                )}

                {selected.status !== 'resolved' && (
                  <div>
                    <p className="label">Add Management Response</p>
                    <textarea className="input resize-none mb-3" rows={4}
                      placeholder="Enter management's response to this finding..."
                      value={response}
                      onChange={e => setResponse(e.target.value)} />
                    <div className="flex gap-2">
                      <button className="btn-amber flex-1 justify-center py-2.5 text-sm" onClick={() => handleAddResponse(selected.id)} disabled={!response}>
                        Record Response
                      </button>
                      {selected.status === 'management_response' && (
                        <button className="btn-ghost border-green/30 text-green hover:bg-green/10 py-2.5 px-4 text-sm" onClick={() => handleResolve(selected.id)}>
                          Mark Resolved ✓
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {selected.resolved_at && (
                  <div className="bg-green/8 border border-green/20 rounded-lg p-4">
                    <p className="text-green font-semibold text-sm">✓ Finding Resolved</p>
                    <p className="text-dim text-[12px] mt-1">{new Date(selected.resolved_at).toLocaleDateString('en-GB', { dateStyle: 'long' })}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* New finding modal */}
        {showNew && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-surface border border-border rounded-2xl p-8 w-[500px]">
              <h2 className="font-display text-xl font-semibold text-white mb-6">Raise New Finding</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Finding Ref</label>
                    <input className="input font-mono" placeholder="F-2025-003" value={form.finding_ref} onChange={e => setForm(f => ({ ...f, finding_ref: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Risk Level</label>
                    <select className="input" value={form.risk_level} onChange={e => setForm(f => ({ ...f, risk_level: e.target.value as RiskLevel }))}>
                      {(['critical','high','medium','low'] as RiskLevel[]).map(r => <option key={r} value={r} className="capitalize">{r.charAt(0).toUpperCase() + r.slice(1)}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="label">Title *</label>
                  <input className="input" placeholder="e.g. Incomplete approval controls — AP" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Description</label>
                  <textarea className="input resize-none" rows={4} placeholder="Describe the issue, evidence, and impact..." value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">ISA Reference</label>
                    <input className="input font-mono" placeholder="e.g. ISA 315" value={form.isa_reference} onChange={e => setForm(f => ({ ...f, isa_reference: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Response Due</label>
                    <input className="input" type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
                  </div>
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreate}>Raise Finding</button>
                <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
