// app/layout.tsx
import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'AuditOS — AI-Powered Audit Intelligence Platform',
  description: 'GL anomaly detection, working paper generation, findings management, and TRA compliance for Tanzania audit firms.',
  keywords: ['audit', 'Tanzania', 'NBAA', 'TRA', 'AI', 'Big Four', 'working papers', 'GL analytics'],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-bg text-white antialiased">
        {children}
      </body>
    </html>
  )
}
