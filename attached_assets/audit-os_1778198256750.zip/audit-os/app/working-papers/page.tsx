'use client'
// app/working-papers/page.tsx
import { useState } from 'react'
import AppLayout from '@/components/layout/AppLayout'
import { DEMO_WORKING_PAPERS, DEMO_ENGAGEMENTS } from '@/types/audit'
import type { WorkingPaper, WPStatus } from '@/types/audit'

const SECTIONS = ['planning', 'controls', 'substantive', 'completion']

const STATUS_CONFIG: Record<WPStatus, { badge: string; label: string; next?: WPStatus; nextLabel?: string }> = {
  draft:      { badge: 'badge-neutral', label: '○ Draft',      next: 'prepared',  nextLabel: 'Mark Prepared' },
  prepared:   { badge: 'badge-pending', label: '◌ Prepared',   next: 'reviewed',  nextLabel: 'Mark Reviewed' },
  reviewed:   { badge: 'badge-medium',  label: '● Reviewed',   next: 'signed_off', nextLabel: 'Sign Off' },
  signed_off: { badge: 'badge-active',  label: '✓ Signed Off', next: undefined, nextLabel: undefined },
}

const SECTION_ICONS: Record<string, string> = {
  planning: '🗂', controls: '🔐', substantive: '📊', completion: '✅'
}

export default function WorkingPapersPage() {
  const [papers, setPapers] = useState<WorkingPaper[]>(DEMO_WORKING_PAPERS)
  const [selected, setSelected] = useState<WorkingPaper | null>(null)
  const [activeSection, setActiveSection] = useState<string>('all')
  const [aiDrafting, setAiDrafting] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [newForm, setNewForm] = useState({ wp_ref: '', section: 'planning', title: '' })
  const [editContent, setEditContent] = useState<string>('')
  const [editMode, setEditMode] = useState(false)
  const [saved, setSaved] = useState(false)

  const engagement = DEMO_ENGAGEMENTS[0]

  const filtered = activeSection === 'all' ? papers : papers.filter(p => p.section === activeSection)
  const signedOff = papers.filter(p => p.status === 'signed_off').length
  const pending = papers.filter(p => p.status !== 'signed_off').length

  const handleSelectWP = (wp: WorkingPaper) => {
    setSelected(wp)
    setEditContent(wp.content_text ?? '')
    setEditMode(false)
    setAiDrafting(false)
  }

  const handleAIDraft = async () => {
    if (!selected) return
    setAiDrafting(true)
    setEditContent('')
    try {
      const res = await fetch('/api/draft-working-paper', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wp: selected, engagement }),
      })
      const data = await res.json()
      setEditContent(data.content ?? 'AI draft unavailable.')
      setPapers(prev => prev.map(p => p.id === selected.id ? { ...p, content_text: data.content, ai_drafted: true } : p))
      setSelected(prev => prev ? { ...prev, content_text: data.content, ai_drafted: true } : prev)
    } catch {
      setEditContent('## Error\n\nFailed to generate AI draft. Check ANTHROPIC_API_KEY.')
    } finally {
      setAiDrafting(false)
    }
  }

  const handleSaveContent = () => {
    setPapers(prev => prev.map(p => p.id === selected?.id ? { ...p, content_text: editContent, status: 'prepared' as WPStatus } : p))
    setSelected(prev => prev ? { ...prev, content_text: editContent, status: 'prepared' as WPStatus } : prev)
    setEditMode(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const handleAdvanceStatus = (wp: WorkingPaper) => {
    const cfg = STATUS_CONFIG[wp.status]
    if (!cfg.next) return
    setPapers(prev => prev.map(p => p.id === wp.id ? { ...p, status: cfg.next! } : p))
    setSelected(prev => prev?.id === wp.id ? { ...prev, status: cfg.next! } : prev)
  }

  const handleCreateWP = () => {
    if (!newForm.wp_ref || !newForm.title) return
    const wp: WorkingPaper = {
      id: `wp-${Date.now()}`,
      engagement_id: engagement.id,
      wp_ref: newForm.wp_ref,
      section: newForm.section,
      title: newForm.title,
      ai_drafted: false,
      content_text: null,
      status: 'draft',
      prepared_by: 'staff-003',
      prepared_at: null,
      reviewed_by: null,
      reviewed_at: null,
      signed_off_by: null,
      signed_off_at: null,
      file_url: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setPapers(prev => [...prev, wp])
    setNewForm({ wp_ref: '', section: 'planning', title: '' })
    setShowNew(false)
  }

  // Simple markdown renderer
  const renderMarkdown = (text: string) => {
    return text
      .split('\n')
      .map((line, i) => {
        if (line.startsWith('## ')) return <h2 key={i} className="font-display text-base font-semibold text-white mt-5 mb-2">{line.slice(3)}</h2>
        if (line.startsWith('# ')) return <h1 key={i} className="font-display text-lg font-semibold text-white mt-5 mb-2">{line.slice(2)}</h1>
        if (line.startsWith('- ') || line.startsWith('* ')) return <li key={i} className="text-muted text-[13px] ml-4 mb-1">{line.slice(2)}</li>
        if (/^\d+\./.test(line)) return <li key={i} className="text-muted text-[13px] ml-4 mb-1 list-decimal">{line.replace(/^\d+\.\s/, '')}</li>
        if (line.trim() === '') return <br key={i} />
        return <p key={i} className="text-muted text-[13px] mb-2 leading-relaxed">{line}</p>
      })
  }

  return (
    <AppLayout>
      <div className="p-10 max-w-[1200px] animate-fade-up">
        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-[11px] text-dim font-bold tracking-[2px] uppercase mb-2">{engagement.engagement_name}</p>
            <h1 className="font-display text-4xl font-semibold text-white mb-2">Working Papers</h1>
            <p className="text-muted text-sm">
              {papers.length} papers · {signedOff} signed off · {pending} in progress
            </p>
          </div>
          <div className="flex gap-3">
            <button className="btn-ghost">Export Bundle</button>
            <button className="btn-primary" onClick={() => setShowNew(true)}>+ New Paper</button>
          </div>
        </div>

        {saved && (
          <div className="flex items-center gap-3 bg-green/8 border border-green/25 rounded-xl px-5 py-3.5 mb-6 text-green text-sm font-semibold">
            ✓ Working paper saved and marked as Prepared.
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-7">
          {SECTIONS.map(section => {
            const sectionPapers = papers.filter(p => p.section === section)
            const done = sectionPapers.filter(p => p.status === 'signed_off').length
            const pct = sectionPapers.length > 0 ? Math.round(done / sectionPapers.length * 100) : 0
            return (
              <div key={section} className="card-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xl">{SECTION_ICONS[section]}</span>
                  <span className="text-[11px] text-dim font-mono">{done}/{sectionPapers.length}</span>
                </div>
                <p className="text-[12px] font-semibold text-white capitalize mb-2">{section}</p>
                <div className="bg-bg-2 rounded-full h-1.5 overflow-hidden">
                  <div className="h-full rounded-full bg-blue transition-all duration-700" style={{ width: `${pct}%` }} />
                </div>
                <p className="text-[10px] text-dim mt-1">{pct}% complete</p>
              </div>
            )
          })}
        </div>

        {/* Section filter */}
        <div className="flex gap-1 bg-surface border border-border rounded-xl p-1 mb-5 w-fit">
          {['all', ...SECTIONS].map(s => (
            <button key={s} onClick={() => setActiveSection(s)}
              className={`px-4 py-2 rounded-lg text-[13px] font-semibold capitalize transition-all
                ${activeSection === s ? 'bg-blue text-white' : 'text-muted hover:text-white'}`}>
              {s === 'all' ? 'All' : s}
            </button>
          ))}
        </div>

        {/* Papers table */}
        <div className="card p-0 overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-border bg-bg-2/60">
                {['Ref', 'Section', 'Title', 'AI Drafted', 'Status', 'Prepared By', ''].map(h => (
                  <th key={h} className="px-5 py-3.5 text-left text-[10px] text-dim font-bold tracking-[1.5px] uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(wp => (
                <tr key={wp.id}
                  className="border-b border-border last:border-0 hover:bg-surface-2/40 transition-colors cursor-pointer"
                  onClick={() => handleSelectWP(wp)}>
                  <td className="px-5 py-4">
                    <span className="font-mono text-[13px] font-semibold text-blue bg-blue/10 border border-blue/20 rounded px-2 py-0.5">{wp.wp_ref}</span>
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1.5 text-[12px] text-muted capitalize">
                      <span>{SECTION_ICONS[wp.section]}</span> {wp.section}
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-[14px] font-medium text-white">{wp.title}</p>
                    {wp.content_text && <p className="text-[11px] text-dim mt-0.5 line-clamp-1">{wp.content_text.replace(/[#*]/g, '').slice(0, 60)}...</p>}
                  </td>
                  <td className="px-5 py-4">
                    {wp.ai_drafted
                      ? <span className="flex items-center gap-1.5 text-[11px] text-blue font-semibold"><span>⬡</span> AI Drafted</span>
                      : <span className="text-[11px] text-dim">Manual</span>
                    }
                  </td>
                  <td className="px-5 py-4">
                    <span className={STATUS_CONFIG[wp.status].badge}>{STATUS_CONFIG[wp.status].label}</span>
                  </td>
                  <td className="px-5 py-4 text-[12px] text-muted">
                    {wp.prepared_by === 'staff-003' ? 'G. Mwamba' : wp.prepared_by ? 'D. Kimaro' : '—'}
                  </td>
                  <td className="px-5 py-4">
                    <button className="text-[12px] text-blue hover:underline">Open →</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* WP detail panel */}
        {selected && (
          <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
            <div className="w-[620px] bg-surface border-l border-border h-full flex flex-col" onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div className="px-7 py-5 border-b border-border flex justify-between items-start shrink-0">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-[12px] text-blue bg-blue/10 border border-blue/20 rounded px-2 py-0.5">{selected.wp_ref}</span>
                    <span className="text-[11px] text-dim capitalize">{selected.section}</span>
                    <span className={STATUS_CONFIG[selected.status].badge}>{STATUS_CONFIG[selected.status].label}</span>
                    {selected.ai_drafted && <span className="badge-medium text-[10px]">⬡ AI Drafted</span>}
                  </div>
                  <h2 className="font-display text-lg font-semibold text-white">{selected.title}</h2>
                </div>
                <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl leading-none mt-1">✕</button>
              </div>

              {/* Toolbar */}
              <div className="px-7 py-3 border-b border-border flex items-center gap-2 shrink-0">
                {!selected.content_text && (
                  <button className="btn-primary text-xs py-2" onClick={handleAIDraft} disabled={aiDrafting}>
                    {aiDrafting ? '⬡ Drafting...' : '⬡ Draft with AI'}
                  </button>
                )}
                {selected.content_text && !editMode && (
                  <button className="btn-ghost text-xs py-2" onClick={() => setEditMode(true)}>Edit</button>
                )}
                {editMode && (
                  <>
                    <button className="btn-primary text-xs py-2" onClick={handleSaveContent}>Save</button>
                    <button className="btn-ghost text-xs py-2" onClick={() => { setEditMode(false); setEditContent(selected.content_text ?? '') }}>Cancel</button>
                    <button className="btn-ghost text-xs py-2" onClick={handleAIDraft} disabled={aiDrafting}>
                      {aiDrafting ? '⬡ Re-drafting...' : '⬡ Re-draft with AI'}
                    </button>
                  </>
                )}
                {STATUS_CONFIG[selected.status].next && (
                  <button className="btn-primary text-xs py-2 ml-auto" onClick={() => handleAdvanceStatus(selected)}>
                    {STATUS_CONFIG[selected.status].nextLabel} →
                  </button>
                )}
              </div>

              {/* Content area */}
              <div className="flex-1 overflow-y-auto px-7 py-6">
                {aiDrafting && (
                  <div className="flex flex-col items-center justify-center h-40 gap-4">
                    <div className="w-10 h-10 border-2 border-blue/30 border-t-blue rounded-full animate-spin" />
                    <div className="text-center">
                      <p className="font-semibold text-white text-sm">Claude is drafting your working paper...</p>
                      <p className="text-dim text-[12px] mt-1">Referencing ISA 315, ISA 330, and NBAA standards</p>
                    </div>
                  </div>
                )}

                {!aiDrafting && editMode && (
                  <textarea
                    className="input resize-none w-full font-mono text-[13px] leading-relaxed"
                    rows={24}
                    value={editContent}
                    onChange={e => setEditContent(e.target.value)}
                    placeholder="Write your working paper content in markdown..."
                  />
                )}

                {!aiDrafting && !editMode && selected.content_text && (
                  <div className="prose-audit">
                    {renderMarkdown(selected.content_text)}
                  </div>
                )}

                {!aiDrafting && !editMode && !selected.content_text && (
                  <div className="flex flex-col items-center justify-center h-60 text-center">
                    <p className="text-4xl mb-4">📄</p>
                    <p className="font-semibold text-white mb-1">No content yet</p>
                    <p className="text-muted text-[13px] mb-5">Draft this working paper manually or let AI generate a professional draft.</p>
                    <div className="flex gap-3">
                      <button className="btn-primary" onClick={handleAIDraft}>⬡ Draft with AI</button>
                      <button className="btn-ghost" onClick={() => setEditMode(true)}>Write Manually</button>
                    </div>
                  </div>
                )}
              </div>

              {/* Sign-off trail */}
              <div className="px-7 py-4 border-t border-border shrink-0 bg-bg-2/40">
                <div className="flex items-center gap-6 text-[11px] text-dim">
                  <span>Prepared: {selected.prepared_at ? new Date(selected.prepared_at).toLocaleDateString('en-GB') : '—'}</span>
                  <span>Reviewed: {selected.reviewed_at ? new Date(selected.reviewed_at).toLocaleDateString('en-GB') : '—'}</span>
                  <span>Signed Off: {selected.signed_off_at ? new Date(selected.signed_off_at).toLocaleDateString('en-GB') : '—'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* New WP modal */}
        {showNew && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-surface border border-border rounded-2xl p-8 w-[440px]">
              <h2 className="font-display text-xl font-semibold text-white mb-6">New Working Paper</h2>
              <div className="space-y-4">
                <div>
                  <label className="label">WP Reference</label>
                  <input className="input font-mono" placeholder="e.g. B2, C3.1" value={newForm.wp_ref} onChange={e => setNewForm(f => ({ ...f, wp_ref: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Section</label>
                  <select className="input" value={newForm.section} onChange={e => setNewForm(f => ({ ...f, section: e.target.value }))}>
                    {SECTIONS.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Title</label>
                  <input className="input" placeholder="e.g. Revenue Substantive Testing" value={newForm.title} onChange={e => setNewForm(f => ({ ...f, title: e.target.value }))} />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreateWP}>Create Paper</button>
                <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
