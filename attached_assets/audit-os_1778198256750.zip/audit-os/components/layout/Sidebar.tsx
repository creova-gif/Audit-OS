'use client'
// components/layout/Sidebar.tsx
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { DEMO_FIRM, DEMO_STAFF } from '@/types/audit'

const NAV = [
  { href: '/dashboard',       icon: '▦',  label: 'Dashboard' },
  { href: '/engagements',     icon: '📁', label: 'Engagements' },
  { href: '/anomalies',       icon: '⚠',  label: 'GL Anomalies',  badge: 4 },
  { href: '/findings',        icon: '🔍', label: 'Findings' },
  { href: '/working-papers',  icon: '📄', label: 'Working Papers' },
  { href: '/clients',         icon: '🏢', label: 'Clients' },
  { href: '/data-room',       icon: '🗄',  label: 'Data Room' },
]

export default function Sidebar() {
  const pathname = usePathname()
  const me = DEMO_STAFF[0]

  return (
    <aside className="fixed top-0 left-0 bottom-0 w-60 bg-surface border-r border-border flex flex-col z-50">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-border">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-8 h-8 bg-blue rounded-lg flex items-center justify-center shrink-0">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <rect x="1" y="1" width="6" height="6" rx="1" fill="white" opacity="0.9"/>
              <rect x="9" y="1" width="6" height="6" rx="1" fill="white" opacity="0.6"/>
              <rect x="1" y="9" width="6" height="6" rx="1" fill="white" opacity="0.6"/>
              <rect x="9" y="9" width="6" height="6" rx="1" fill="white" opacity="0.3"/>
            </svg>
          </div>
          <div>
            <div className="font-display text-base font-semibold text-white leading-none">AuditOS</div>
            <div className="text-[9px] text-blue font-bold tracking-[2px] uppercase mt-0.5">by CREOVA</div>
          </div>
        </div>
      </div>

      {/* Firm badge */}
      <div className="px-4 py-3.5 border-b border-border">
        <div className="bg-navy border border-blue/20 rounded-lg px-3 py-2.5">
          <div className="text-[10px] text-blue/70 font-bold tracking-[1px] uppercase mb-0.5">Active Firm</div>
          <div className="text-[13px] font-semibold text-white">{DEMO_FIRM.name}</div>
          <div className="text-[11px] text-dim mt-0.5">
            {DEMO_FIRM.tier.replace('_',' ').toUpperCase()} · NBAA {DEMO_FIRM.nbaa_reg_no}
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 overflow-y-auto">
        <div className="text-[10px] text-dim font-bold tracking-[1.5px] uppercase px-3 mb-2">Navigation</div>
        {NAV.map(item => {
          const active = pathname === item.href || pathname.startsWith(item.href + '/')
          return (
            <Link key={item.href} href={item.href}
              className={`flex items-center gap-2.5 w-full px-3 py-2.5 rounded-lg text-[13px] font-medium mb-0.5 transition-all relative
                ${active
                  ? 'bg-blue/12 text-blue border-l-2 border-blue pl-[10px]'
                  : 'text-muted hover:text-white hover:bg-surface-2 border-l-2 border-transparent pl-[10px]'
                }`}>
              <span className="text-base w-5 text-center shrink-0">{item.icon}</span>
              <span className="flex-1">{item.label}</span>
              {item.badge && (
                <span className="bg-red text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center shrink-0">
                  {item.badge}
                </span>
              )}
            </Link>
          )
        })}
      </nav>

      {/* User */}
      <div className="px-4 py-4 border-t border-border">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-full bg-blue/20 border border-blue/30 flex items-center justify-center text-blue text-xs font-bold shrink-0">
            {me.full_name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold text-white truncate">{me.full_name}</div>
            <div className="text-[11px] text-dim capitalize">{me.role} · {me.nbaa_member_no}</div>
          </div>
        </div>
        <Link href="/auth/logout"
          className="flex items-center gap-2 w-full px-2 py-1.5 text-[12px] text-dim hover:text-white rounded transition-colors">
          ← Sign Out
        </Link>
      </div>
    </aside>
  )
}
