/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-instrument)', 'serif'],
        body: ['var(--font-geist)', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'monospace'],
      },
      colors: {
        bg:      { DEFAULT: '#0b0d11', 2: '#111418' },
        surface: { DEFAULT: '#161b24', 2: '#1e2535' },
        border:  { DEFAULT: '#222c3c', 2: '#2d3d54' },
        navy:    '#0f2044',
        blue:    { DEFAULT: '#3b82f6', light: '#60a5fa' },
        gold:    { DEFAULT: '#d4a017', light: '#f0c040' },
        teal:    { DEFAULT: '#0ea5e9', light: '#38bdf8' },
        red:     '#ef4444',
        amber:   '#f59e0b',
        green:   '#22c55e',
        muted:   '#7a8ba8',
        dim:     '#3d5068',
      },
    },
  },
  plugins: [],
}
