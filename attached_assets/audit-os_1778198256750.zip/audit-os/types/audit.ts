// types/audit.ts

export type FirmTier = 'big4' | 'mid_tier' | 'small_firm' | 'internal'
export type EngagementStatus = 'planning' | 'fieldwork' | 'review' | 'completed' | 'archived'
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical'
export type FindingStatus = 'open' | 'management_response' | 'resolved' | 'escalated'
export type WPStatus = 'draft' | 'prepared' | 'reviewed' | 'signed_off'

export interface Firm {
  id: string
  name: string
  tier: FirmTier
  country: string
  nbaa_reg_no: string | null
  contact_email: string | null
  subscription_tier: string
  is_active: boolean
  created_at: string
}

export interface Staff {
  id: string
  user_id: string | null
  firm_id: string
  full_name: string
  email: string
  role: string
  nbaa_member_no: string | null
  is_active: boolean
  created_at: string
}

export interface Client {
  id: string
  firm_id: string
  name: string
  tin: string | null
  industry: string | null
  entity_type: string | null
  financial_year_end: string | null
  contact_name: string | null
  contact_email: string | null
  contact_phone: string | null
  is_active: boolean
  created_at: string
}

export interface Engagement {
  id: string
  firm_id: string
  client_id: string
  engagement_name: string
  period_start: string
  period_end: string
  engagement_type: string
  status: EngagementStatus
  partner_id: string | null
  manager_id: string | null
  materiality_usd: number | null
  performance_mat_usd: number | null
  overall_risk: RiskLevel
  report_date: string | null
  signed_off_at: string | null
  notes: string | null
  created_at: string
  updated_at: string
  // joined
  client?: Client
}

export interface GLUpload {
  id: string
  engagement_id: string
  file_name: string
  file_url: string | null
  period_start: string | null
  period_end: string | null
  total_debits: number | null
  total_credits: number | null
  entry_count: number | null
  upload_status: string
  ai_analysis_done: boolean
  uploaded_by: string | null
  created_at: string
}

export interface GLAnomaly {
  id: string
  gl_upload_id: string
  engagement_id: string
  anomaly_type: string
  risk_level: RiskLevel
  account_code: string | null
  account_name: string | null
  journal_ref: string | null
  transaction_date: string | null
  amount: number | null
  description: string | null
  ai_explanation: string | null
  auditor_status: string
  auditor_notes: string | null
  reviewed_by: string | null
  reviewed_at: string | null
  created_at: string
}

export interface Finding {
  id: string
  engagement_id: string
  anomaly_id: string | null
  finding_ref: string
  title: string
  description: string
  risk_level: RiskLevel
  isa_reference: string | null
  nbaa_reference: string | null
  management_response: string | null
  status: FindingStatus
  due_date: string | null
  resolved_at: string | null
  raised_by: string | null
  created_at: string
  updated_at: string
}

export interface WorkingPaper {
  id: string
  engagement_id: string
  wp_ref: string
  section: string
  title: string
  ai_drafted: boolean
  content_text: string | null
  status: WPStatus
  prepared_by: string | null
  prepared_at: string | null
  reviewed_by: string | null
  reviewed_at: string | null
  signed_off_by: string | null
  signed_off_at: string | null
  file_url: string | null
  created_at: string
  updated_at: string
}

export interface DataRoomItem {
  id: string
  engagement_id: string
  category: string
  item_name: string
  description: string | null
  requested_at: string
  due_date: string | null
  received_at: string | null
  file_url: string | null
  file_name: string | null
  status: string
  requested_by: string | null
  created_at: string
}

export interface EFDRecord {
  id: string
  engagement_id: string
  receipt_no: string
  receipt_date: string
  amount_tzs: number
  vat_amount: number | null
  customer_tin: string | null
  gl_matched: boolean | null
  variance_tzs: number | null
  risk_flag: boolean
  created_at: string
}

// ── MOCK DATA ─────────────────────────────────────────────────

export const DEMO_FIRM: Firm = {
  id: 'firm-001',
  name: 'PwC Tanzania',
  tier: 'big4',
  country: 'TZ',
  nbaa_reg_no: 'NBAA-F-0012',
  contact_email: 'tanzania@pwc.com',
  subscription_tier: 'firm',
  is_active: true,
  created_at: '2024-01-01T00:00:00Z',
}

export const DEMO_STAFF: Staff[] = [
  { id: 'staff-001', user_id: null, firm_id: 'firm-001', full_name: 'Amina Rashidi', email: 'a.rashidi@pwc.com', role: 'partner', nbaa_member_no: 'NBAA-A-1042', is_active: true, created_at: '2024-01-01Z' },
  { id: 'staff-002', user_id: null, firm_id: 'firm-001', full_name: 'David Kimaro', email: 'd.kimaro@pwc.com', role: 'manager', nbaa_member_no: 'NBAA-A-2081', is_active: true, created_at: '2024-01-01Z' },
  { id: 'staff-003', user_id: null, firm_id: 'firm-001', full_name: 'Grace Mwamba', email: 'g.mwamba@pwc.com', role: 'senior', nbaa_member_no: 'NBAA-A-3340', is_active: true, created_at: '2024-01-01Z' },
]

export const DEMO_CLIENTS: Client[] = [
  { id: 'client-001', firm_id: 'firm-001', name: 'Tanzania Breweries Ltd', tin: '123-456-789', industry: 'Manufacturing', entity_type: 'company', financial_year_end: 'Dec', contact_name: 'John Makamba', contact_email: 'j.makamba@tbl.co.tz', contact_phone: '+255 22 211 0000', is_active: true, created_at: '2024-01-01Z' },
  { id: 'client-002', firm_id: 'firm-001', name: 'TANESCO', tin: '987-654-321', industry: 'Utilities', entity_type: 'parastatal', financial_year_end: 'Jun', contact_name: 'Sarah Njau', contact_email: 's.njau@tanesco.co.tz', contact_phone: '+255 22 211 5000', is_active: true, created_at: '2024-01-01Z' },
  { id: 'client-003', firm_id: 'firm-001', name: 'Serengeti Breweries', tin: '456-789-123', industry: 'Manufacturing', entity_type: 'company', financial_year_end: 'Dec', contact_name: 'Peter Osei', contact_email: 'p.osei@serengeti.co.tz', contact_phone: '+255 22 219 0000', is_active: true, created_at: '2024-02-01Z' },
  { id: 'client-004', firm_id: 'firm-001', name: 'CRDB Bank PLC', tin: '321-654-987', industry: 'Banking', entity_type: 'company', financial_year_end: 'Dec', contact_name: 'Linda Mushi', contact_email: 'l.mushi@crdbbank.co.tz', contact_phone: '+255 22 213 0000', is_active: true, created_at: '2024-02-15Z' },
]

export const DEMO_ENGAGEMENTS: Engagement[] = [
  { id: 'eng-001', firm_id: 'firm-001', client_id: 'client-001', engagement_name: 'TBL Statutory Audit FY2025', period_start: '2025-01-01', period_end: '2025-12-31', engagement_type: 'statutory_audit', status: 'fieldwork', partner_id: 'staff-001', manager_id: 'staff-002', materiality_usd: 850000, performance_mat_usd: 637500, overall_risk: 'medium', report_date: '2026-03-31', signed_off_at: null, notes: 'Key risk: revenue recognition on bulk export contracts. EFD reconciliation required.', created_at: '2025-09-01Z', updated_at: '2026-04-01Z', client: DEMO_CLIENTS[0] },
  { id: 'eng-002', firm_id: 'firm-001', client_id: 'client-002', engagement_name: 'TANESCO Internal Audit Q1 2026', period_start: '2026-01-01', period_end: '2026-03-31', engagement_type: 'internal_audit', status: 'review', partner_id: 'staff-001', manager_id: 'staff-002', materiality_usd: 2000000, performance_mat_usd: 1500000, overall_risk: 'high', report_date: '2026-04-30', signed_off_at: null, notes: 'Focus on procurement compliance and PPRA adherence.', created_at: '2026-01-05Z', updated_at: '2026-04-01Z', client: DEMO_CLIENTS[1] },
  { id: 'eng-003', firm_id: 'firm-001', client_id: 'client-004', engagement_name: 'CRDB Bank Due Diligence', period_start: '2025-07-01', period_end: '2025-09-30', engagement_type: 'due_diligence', status: 'completed', partner_id: 'staff-001', manager_id: 'staff-003', materiality_usd: 500000, performance_mat_usd: 375000, overall_risk: 'low', report_date: '2025-10-15', signed_off_at: '2025-10-14T16:00:00Z', notes: null, created_at: '2025-06-01Z', updated_at: '2025-10-14Z', client: DEMO_CLIENTS[3] },
]

export const DEMO_ANOMALIES: GLAnomaly[] = [
  { id: 'anom-001', gl_upload_id: 'upload-001', engagement_id: 'eng-001', anomaly_type: 'round_number', risk_level: 'high', account_code: '5001', account_name: 'Cost of Sales', journal_ref: 'JE-2025-08841', transaction_date: '2025-11-30', amount: 500000, description: 'Round-number journal entry on last day of November. No supporting narrative.', ai_explanation: 'Journal entries with round numbers (divisible by 100,000) are statistically rare in normal operations and are a known indicator of earnings management. This entry on the final day of the month further elevates risk as it may represent a period-end manipulation. ISA 240 requires investigation of unusual journal entries near period end.', auditor_status: 'unreviewed', auditor_notes: null, reviewed_by: null, reviewed_at: null, created_at: '2026-04-01Z' },
  { id: 'anom-002', gl_upload_id: 'upload-001', engagement_id: 'eng-001', anomaly_type: 'weekend_entry', risk_level: 'critical', account_code: '1200', account_name: 'Accounts Receivable', journal_ref: 'JE-2025-09102', transaction_date: '2025-12-28', amount: 1842000, description: 'AR credit entry posted on Sunday Dec 28. Posted by: system_admin.', ai_explanation: 'Journal entries posted on weekends, particularly by administrator-level accounts, are a significant red flag for fraudulent activity. This entry writes off TZS 1.84M of receivables outside of normal business hours and outside the standard month-end close process. Under ISA 240 this requires mandatory investigation. Request: (1) approval authorization, (2) supporting documentation for the write-off, (3) IT access log for the system_admin account on Dec 28.', auditor_status: 'unreviewed', auditor_notes: null, reviewed_by: null, reviewed_at: null, created_at: '2026-04-01Z' },
  { id: 'anom-003', gl_upload_id: 'upload-001', engagement_id: 'eng-001', anomaly_type: 'duplicate', risk_level: 'high', account_code: '6200', account_name: 'Professional Fees', journal_ref: 'JE-2025-07215', transaction_date: '2025-10-15', amount: 95000, description: 'Duplicate vendor invoice detected. Same amount, same vendor TIN, within 7 days of JE-2025-07198.', ai_explanation: 'A potential duplicate payment of TZS 95,000 to the same vendor within a 7-day window. Duplicate payments are among the most common forms of vendor fraud and accounts payable error. This should be confirmed against the original invoice, delivery receipt, and payment confirmation. If both payments were made, one should be recovered or applied as a credit to the next invoice cycle.', auditor_status: 'investigated', auditor_notes: 'Confirmed duplicate. Vendor has been contacted. Credit note expected May 2026.', reviewed_by: 'staff-003', reviewed_at: '2026-04-02T09:00:00Z', created_at: '2026-04-01Z' },
  { id: 'anom-004', gl_upload_id: 'upload-001', engagement_id: 'eng-001', anomaly_type: 'outlier', risk_level: 'medium', account_code: '7100', account_name: 'Travel & Subsistence', journal_ref: 'JE-2025-06440', transaction_date: '2025-09-22', amount: 34500, description: 'Single travel claim 4.2x above the mean for this cost centre. Approved by same employee.', ai_explanation: 'This travel claim is 4.2 standard deviations above the mean for the Travel & Subsistence cost centre over the past 12 months. Additionally, the approval was made by the same employee who submitted the claim, bypassing the segregation of duties control. This raises two concerns: (1) potential inflated expense claim, and (2) control override. Request supporting receipts and an explanation for the self-approval.', auditor_status: 'unreviewed', auditor_notes: null, reviewed_by: null, reviewed_at: null, created_at: '2026-04-01Z' },
  { id: 'anom-005', gl_upload_id: 'upload-001', engagement_id: 'eng-001', anomaly_type: 'large_reversal', risk_level: 'medium', account_code: '4000', account_name: 'Revenue', journal_ref: 'JE-2025-09890', transaction_date: '2025-12-31', amount: -2100000, description: 'Revenue reversal of TZS 2.1M on Dec 31 (year-end). Original entry: JE-2025-05321 dated June 15.', ai_explanation: 'A TZS 2.1M revenue reversal on the last day of the financial year is a significant cut-off risk. Reversals of 6-month-old revenue entries at year-end may indicate: (1) incorrect revenue recognition in the original period, (2) a disputed sale being reversed, or (3) deliberate manipulation of year-end balances. This entry should be tested against the underlying contract, delivery records, and customer correspondence.', auditor_status: 'unreviewed', auditor_notes: null, reviewed_by: null, reviewed_at: null, created_at: '2026-04-01Z' },
]

export const DEMO_FINDINGS: Finding[] = [
  { id: 'find-001', engagement_id: 'eng-001', anomaly_id: 'anom-003', finding_ref: 'F-2025-001', title: 'Duplicate Vendor Payment — Professional Fees', description: 'A duplicate payment of TZS 95,000 was identified to vendor TIN 456-XXX-789. The same invoice amount was processed twice within 7 days (JE-2025-07198 and JE-2025-07215). This indicates a weakness in the accounts payable matching controls.', risk_level: 'high', isa_reference: 'ISA 315', nbaa_reference: null, management_response: 'Management acknowledges the duplicate payment. A credit note has been requested from the vendor and is expected by May 2026. AP controls have been reviewed and a 3-way match requirement has been implemented for all invoices above TZS 50,000.', status: 'management_response', due_date: '2026-05-31', resolved_at: null, raised_by: 'staff-003', created_at: '2026-04-02Z', updated_at: '2026-04-05Z' },
  { id: 'find-002', engagement_id: 'eng-001', anomaly_id: 'anom-004', finding_ref: 'F-2025-002', title: 'Segregation of Duties — Travel Expense Approval', description: 'An employee approved their own travel expense claim of TZS 34,500, which is 4.2x above the cost centre average. The expense approval workflow does not prevent self-approval for amounts below TZS 100,000.', risk_level: 'medium', isa_reference: 'ISA 315', nbaa_reference: null, management_response: null, status: 'open', due_date: '2026-06-30', resolved_at: null, raised_by: 'staff-002', created_at: '2026-04-03Z', updated_at: '2026-04-03Z' },
]

export const DEMO_WORKING_PAPERS: WorkingPaper[] = [
  { id: 'wp-001', engagement_id: 'eng-001', wp_ref: 'A1', section: 'planning', title: 'Engagement Acceptance & Continuance', ai_drafted: false, content_text: 'Engagement accepted following assessment of client integrity, competence, and independence requirements per ISQM 1.', status: 'signed_off', prepared_by: 'staff-002', prepared_at: '2025-09-05T09:00:00Z', reviewed_by: 'staff-001', reviewed_at: '2025-09-08T14:00:00Z', signed_off_by: 'staff-001', signed_off_at: '2025-09-08T14:30:00Z', file_url: null, created_at: '2025-09-01Z', updated_at: '2025-09-08Z' },
  { id: 'wp-002', engagement_id: 'eng-001', wp_ref: 'A2', section: 'planning', title: 'Materiality Calculation', ai_drafted: true, content_text: 'Planning materiality set at USD 850,000 (0.5% of gross revenue). Performance materiality set at USD 637,500 (75% of planning materiality). Threshold for clearly trivial: USD 42,500.', status: 'reviewed', prepared_by: 'staff-003', prepared_at: '2025-09-10T10:00:00Z', reviewed_by: 'staff-002', reviewed_at: '2025-09-12T11:00:00Z', signed_off_by: null, signed_off_at: null, file_url: null, created_at: '2025-09-08Z', updated_at: '2025-09-12Z' },
  { id: 'wp-003', engagement_id: 'eng-001', wp_ref: 'B1', section: 'controls', title: 'Internal Controls Assessment — Revenue', ai_drafted: true, content_text: null, status: 'draft', prepared_by: 'staff-003', prepared_at: null, reviewed_by: null, reviewed_at: null, signed_off_by: null, signed_off_at: null, file_url: null, created_at: '2025-10-01Z', updated_at: '2025-10-01Z' },
  { id: 'wp-004', engagement_id: 'eng-001', wp_ref: 'C1', section: 'substantive', title: 'Revenue Substantive Testing', ai_drafted: false, content_text: 'Sample of 45 revenue transactions selected using MUS. 43 agreed to supporting documentation. 2 items require further investigation (see schedule C1-A).', status: 'prepared', prepared_by: 'staff-003', prepared_at: '2026-02-15T09:00:00Z', reviewed_by: null, reviewed_at: null, signed_off_by: null, signed_off_at: null, file_url: null, created_at: '2026-02-01Z', updated_at: '2026-02-15Z' },
]

export const DEMO_DATA_ROOM: DataRoomItem[] = [
  { id: 'dr-001', engagement_id: 'eng-001', category: 'financial_statements', item_name: 'Draft Financial Statements FY2025', description: 'Full IFRS financial statements including notes', requested_at: '2026-01-15T09:00:00Z', due_date: '2026-01-31', received_at: '2026-01-28T14:00:00Z', file_url: '#', file_name: 'TBL_FS_FY2025_Draft_v2.pdf', status: 'reviewed', requested_by: 'staff-002', created_at: '2026-01-15Z' },
  { id: 'dr-002', engagement_id: 'eng-001', category: 'bank_statements', item_name: 'Bank Statements Dec 2025 — All Accounts', description: '12 accounts across CRDB, NMB, Stanbic', requested_at: '2026-01-15T09:00:00Z', due_date: '2026-01-31', received_at: '2026-02-03T10:00:00Z', file_url: '#', file_name: 'TBL_Bank_Dec2025.zip', status: 'reviewed', requested_by: 'staff-003', created_at: '2026-01-15Z' },
  { id: 'dr-003', engagement_id: 'eng-001', category: 'tax_returns', item_name: 'TRA VAT Returns Q3 & Q4 2025', description: 'EFD-certified VAT returns for cross-reference with GL', requested_at: '2026-02-01T09:00:00Z', due_date: '2026-02-15', received_at: null, file_url: null, file_name: null, status: 'requested', requested_by: 'staff-002', created_at: '2026-02-01Z' },
  { id: 'dr-004', engagement_id: 'eng-001', category: 'contracts', item_name: 'Top 10 Revenue Contracts FY2025', description: 'Contracts supporting revenue recognition assessment', requested_at: '2026-01-20T09:00:00Z', due_date: '2026-02-01', received_at: '2026-02-05T09:00:00Z', file_url: '#', file_name: 'TBL_Revenue_Contracts_Top10.zip', status: 'queried', requested_by: 'staff-003', created_at: '2026-01-20Z' },
  { id: 'dr-005', engagement_id: 'eng-001', category: 'board_minutes', item_name: 'Board Minutes — All 2025 Meetings', description: 'Required for identification of significant transactions', requested_at: '2026-01-15T09:00:00Z', due_date: '2026-01-31', received_at: '2026-01-29T11:00:00Z', file_url: '#', file_name: 'TBL_Board_Minutes_2025.pdf', status: 'received', requested_by: 'staff-002', created_at: '2026-01-15Z' },
]

export const ENGAGEMENT_PROGRESS = {
  planning: 100,
  fieldwork: 65,
  review: 0,
  completion: 0,
}
